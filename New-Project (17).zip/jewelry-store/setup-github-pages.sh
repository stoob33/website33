#!/bin/bash

echo "🚀 GitHub Pages Setup for Jewelry Doctor"
echo "=========================================="
echo ""

# Ask deployment type
echo "How will you deploy this site?"
echo "1) Custom domain (e.g., jewelrydoctor.com)"
echo "2) GitHub subdirectory (e.g., username.github.io/repo-name)"
echo "3) User site (repo named username.github.io)"
echo ""
read -p "Enter your choice (1-3): " choice

case $choice in
  1)
    echo ""
    read -p "Enter your custom domain (e.g., jewelrydoctor.com): " domain
    echo "$domain" > public/CNAME
    echo "✅ Created public/CNAME with: $domain"
    echo ""
    echo "📝 Next steps:"
    echo "1. Add CNAME record at your domain registrar pointing to YOUR_USERNAME.github.io"
    echo "2. Or add A records pointing to GitHub's IPs"
    echo "3. Push to GitHub and enable Pages in Settings > Pages"
    echo "4. Add custom domain in GitHub Pages settings"
    echo "5. Wait for DNS propagation (up to 48 hours)"
    ;;
  2)
    echo ""
    read -p "Enter your repository name: " repo_name

    # Update next.config.js with basePath
    sed -i.bak "s|// basePath:.*|basePath: '/$repo_name',|" next.config.js
    rm -f next.config.js.bak

    echo "✅ Updated next.config.js with basePath: /$repo_name"
    echo ""
    echo "📝 Next steps:"
    echo "1. Build: bun run build"
    echo "2. Commit: git add . && git commit -m 'Configure basePath'"
    echo "3. Push: git push"
    echo "4. Your site will be at: https://YOUR_USERNAME.github.io/$repo_name/"
    ;;
  3)
    echo ""
    echo "✅ No configuration needed for user site"
    echo ""
    echo "📝 Next steps:"
    echo "1. Make sure your repository is named: YOUR_USERNAME.github.io"
    echo "2. Push to GitHub"
    echo "3. Enable Pages in Settings > Pages > Source: GitHub Actions"
    echo "4. Your site will be at: https://YOUR_USERNAME.github.io/"
    ;;
  *)
    echo "❌ Invalid choice"
    exit 1
    ;;
esac

echo ""
echo "✅ Setup complete!"
echo ""
echo "📚 See DEPLOY.md for detailed instructions"
