(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_4561a759._.js",
  "static/chunks/src_cadc423b._.js"
],
    source: "dynamic"
});
