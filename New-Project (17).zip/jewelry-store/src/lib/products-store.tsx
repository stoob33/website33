"use client";

import { createContext, useContext, useState, useEffect } from "react";
import { Product, products as initialProducts } from "./products";

interface ProductsContextType {
  products: Product[];
  isLoading: boolean;
  addProduct: (product: Product) => void;
  updateProduct: (id: string, product: Product) => void;
  deleteProduct: (id: string) => void;
  getProductById: (id: string) => Product | undefined;
}

const ProductsContext = createContext<ProductsContextType | undefined>(undefined);

export function ProductsProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Load products from localStorage or use initial products
    const savedProducts = localStorage.getItem("products");
    if (savedProducts) {
      try {
        const parsed = JSON.parse(savedProducts);
        // Check if products have prices property and updated images
        const hasAllPrices = parsed.every((p: Product) => p.prices);
        const hasOldImages = parsed.some((p: Product) =>
          p.images.some((img: string) => img.includes('unsplash.com'))
        );

        if (hasAllPrices && !hasOldImages) {
          setProducts(parsed);
        } else {
          // Reset to initial products if any product is missing prices or has old images
          setProducts(initialProducts);
          localStorage.setItem("products", JSON.stringify(initialProducts));
        }
      } catch (e) {
        // If parsing fails, use initial products
        setProducts(initialProducts);
        localStorage.setItem("products", JSON.stringify(initialProducts));
      }
    } else {
      setProducts(initialProducts);
      // Save initial products to localStorage
      localStorage.setItem("products", JSON.stringify(initialProducts));
    }
    setIsLoading(false);
  }, []);

  const saveProducts = (newProducts: Product[]) => {
    console.log("saveProducts called with:", newProducts);
    setProducts(newProducts);
    localStorage.setItem("products", JSON.stringify(newProducts));
    console.log("Products saved to localStorage!");
    console.log("Verifying save:", localStorage.getItem("products"));
  };

  const addProduct = (product: Product) => {
    console.log("addProduct called with:", product);
    console.log("Current products:", products);
    const newProducts = [...products, product];
    console.log("New products array:", newProducts);
    saveProducts(newProducts);
    console.log("Product added and saved!");
  };

  const updateProduct = (id: string, updatedProduct: Product) => {
    console.log("updateProduct called with:", id, updatedProduct);
    console.log("Current products:", products);
    const newProducts = products.map((p) =>
      p.id === id ? updatedProduct : p
    );
    console.log("New products array:", newProducts);
    saveProducts(newProducts);
    console.log("Product updated and saved!");
  };

  const deleteProduct = (id: string) => {
    const newProducts = products.filter((p) => p.id !== id);
    saveProducts(newProducts);
  };

  const getProductById = (id: string) => {
    return products.find((p) => p.id === id);
  };

  return (
    <ProductsContext.Provider
      value={{
        products,
        isLoading,
        addProduct,
        updateProduct,
        deleteProduct,
        getProductById,
      }}
    >
      {children}
    </ProductsContext.Provider>
  );
}

export function useProducts() {
  const context = useContext(ProductsContext);
  if (context === undefined) {
    throw new Error("useProducts must be used within a ProductsProvider");
  }
  return context;
}
