export interface Product {
  id: string;
  name: string;
  description: string;
  images: string[];
  metal: {
    options: string[];
    default: string;
  };
  shape: string;
  color: {
    options: string[];
    default: string;
  };
  clarity: {
    options: string[];
    default: string;
  };
  weight: {
    options: string[];
    default: string;
  };
  prices: {
    [key: string]: number; // Price for each weight option
  };
}

export const products: Product[] = [
  {
    id: "LG2224P-RD-20",
    name: "14K White Gold Lab Grown Diamond 2 3/8 Ct.Tw. Round Hidden Halo Engagement Ring (IGI Certified Center 2ct)",
    description: "This eye-catching wedding is available in 14k White Gold. There are 34 round diamonds with a total carat weight of 2.41ct set in a Micro Prong setting.",
    images: [
      "https://i.imgur.com/uTUnuSC.jpg",
      "https://i.imgur.com/SJioxBF.jpg",
      "https://i.imgur.com/bd9laNB.jpg",
      "https://i.imgur.com/awCuWmv.jpg"
    ],
    metal: {
      options: ["14k White Gold", "14k Yellow Gold"],
      default: "14k White Gold"
    },
    shape: "ROUND",
    color: {
      options: ["D-F"],
      default: "D-F"
    },
    clarity: {
      options: ["VS"],
      default: "VS"
    },
    weight: {
      options: ["2.41 ct.", "3.42 ct.", "4.54 ct."],
      default: "2.41 ct."
    },
    prices: {
      "2.41 ct.": 2500,
      "3.42 ct.": 3800,
      "4.54 ct.": 5200
    }
  },
  {
    id: "LG2224W-PE-20",
    name: "14K White Gold Lab Grown Diamond 2 3/8 Ct.Tw. Pear Hidden Halo Engagement Ring",
    description: "This eye-catching wedding is available in 14k White Gold. There are 34 round diamonds with a total carat weight of 2.41ct set in a Micro Prong setting.",
    images: [
      "https://i.imgur.com/8EKCQFh.jpg",
      "https://i.imgur.com/8Z123JP.jpg",
      "https://i.imgur.com/h5chKGf.jpg",
      "https://i.imgur.com/5xpSOki.jpg"
    ],
    metal: {
      options: ["14k White Gold", "14k Yellow Gold"],
      default: "14k White Gold"
    },
    shape: "PEAR",
    color: {
      options: ["D-F"],
      default: "D-F"
    },
    clarity: {
      options: ["VS"],
      default: "VS"
    },
    weight: {
      options: ["2.41 ct.", "3.42 ct.", "4.54 ct."],
      default: "2.41 ct."
    },
    prices: {
      "2.41 ct.": 2500,
      "3.42 ct.": 3800,
      "4.54 ct.": 5200
    }
  },
  {
    id: "LG2224W-OV-20",
    name: "14K White Gold Lab Grown Diamond 2 3/8 Ct.Tw. Oval Hidden Halo Engagement Ring",
    description: "This eye-catching wedding is available in 14k White Gold. There are 34 round diamonds with a total carat weight of 2.41ct set in a Micro Prong setting.",
    images: [
      "https://i.imgur.com/tpvlLhJ.jpg",
      "https://i.imgur.com/A9nQPWc.jpg",
      "https://i.imgur.com/RBZbcZO.jpg",
      "https://i.imgur.com/NVewFhM.jpg"
    ],
    metal: {
      options: ["14k White Gold", "14k Yellow Gold"],
      default: "14k White Gold"
    },
    shape: "OVAL",
    color: {
      options: ["D-F"],
      default: "D-F"
    },
    clarity: {
      options: ["VS"],
      default: "VS"
    },
    weight: {
      options: ["2.41 ct.", "3.42 ct.", "4.54 ct."],
      default: "2.41 ct."
    },
    prices: {
      "2.41 ct.": 2500,
      "3.42 ct.": 3800,
      "4.54 ct.": 5200
    }
  },
  {
    id: "LG2224W-EM-20",
    name: "14K White Gold Lab Grown Diamond 2 3/8 Ct.Tw. Emerald Hidden Halo Engagement Ring",
    description: "This eye-catching wedding is available in 14k White Gold. There are 34 round diamonds with a total carat weight of 2.41ct set in a Micro Prong setting.",
    images: [
      "https://i.imgur.com/zoxA1ey.jpg",
      "https://i.imgur.com/7g3hKO5.jpg",
      "https://i.imgur.com/cKKu4PG.jpg",
      "https://i.imgur.com/R3b53xN.jpg"
    ],
    metal: {
      options: ["14k White Gold", "14k Yellow Gold"],
      default: "14k White Gold"
    },
    shape: "EMERALD",
    color: {
      options: ["D-F"],
      default: "D-F"
    },
    clarity: {
      options: ["VS"],
      default: "VS"
    },
    weight: {
      options: ["2.41 ct.", "3.42 ct.", "4.54 ct."],
      default: "2.41 ct."
    },
    prices: {
      "2.41 ct.": 2500,
      "3.42 ct.": 3800,
      "4.54 ct.": 5200
    }
  }
];

export function getProductById(id: string): Product | undefined {
  return products.find(p => p.id === id);
}
