import Image from "next/image";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  className?: string;
}

export default function Logo({ size = "md", className = "" }: LogoProps) {
  const sizes = {
    sm: { container: "w-12 h-12", text: "text-2xl" },
    md: { container: "w-32 h-32", text: "text-8xl" },
    lg: { container: "w-48 h-48", text: "text-9xl" }
  };

  const currentSize = sizes[size];

  // You can replace this with your actual logo path
  // For now, using a golden diamond icon as placeholder
  return (
    <div className={`${currentSize.container} ${className} relative flex items-center justify-center`}>
      {/* Replace /logo.png with your actual logo file */}
      {/* When you upload your logo, it will automatically show here */}
      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-yellow-500 via-yellow-400 to-yellow-600 rounded-lg shadow-xl">
        <svg
          viewBox="0 0 24 24"
          fill="none"
          className="w-3/4 h-3/4"
          stroke="currentColor"
          strokeWidth="1.5"
        >
          <path
            d="M12 2L4 7L12 12L20 7L12 2Z"
            fill="white"
            stroke="white"
          />
          <path
            d="M4 7L12 22L20 7"
            fill="url(#diamond-gradient)"
            stroke="white"
          />
          <defs>
            <linearGradient id="diamond-gradient" x1="12" y1="7" x2="12" y2="22" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="rgba(255,255,255,0.9)" />
              <stop offset="100%" stopColor="rgba(255,255,255,0.6)" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}
