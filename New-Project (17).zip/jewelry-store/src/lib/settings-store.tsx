"use client";

import { createContext, useContext, useState, useEffect } from "react";

interface Settings {
  description: string;
  subtitle: string;
}

interface SettingsContextType {
  settings: Settings;
  updateSettings: (settings: Settings) => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

const defaultSettings: Settings = {
  description: "At Jewelry Doctor, we specialize in all types of jewelry repair, from resizing rings and fixing chains to replacing watch batteries and repairing settings. We also offer custom jewelry design, engraving, and plating services, helping you create or restore pieces exactly the way you want them. One of our most popular features is same-day jewelry repair, so you can get your treasured items back quickly and in perfect condition.",
  subtitle: "Create your perfect ring with our custom design options."
};

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<Settings>(defaultSettings);

  useEffect(() => {
    const savedSettings = localStorage.getItem("settings");
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }
  }, []);

  const updateSettings = (newSettings: Settings) => {
    setSettings(newSettings);
    localStorage.setItem("settings", JSON.stringify(newSettings));
  };

  return (
    <SettingsContext.Provider value={{ settings, updateSettings }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error("useSettings must be used within a SettingsProvider");
  }
  return context;
}
