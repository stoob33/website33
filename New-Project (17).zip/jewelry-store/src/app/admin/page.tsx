"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";
import { useProducts } from "@/lib/products-store";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Logo from "@/components/Logo";
import Footer from "@/components/Footer";
import Image from "next/image";

export default function AdminDashboard() {
  const { isAdmin, isLoading: authLoading } = useAuth();
  const { products, deleteProduct, isLoading: productsLoading } = useProducts();
  const router = useRouter();

  useEffect(() => {
    if (!authLoading && !isAdmin) {
      router.push("/");
    }
  }, [isAdmin, authLoading, router]);

  if (authLoading || productsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-slate-600">Loading...</p>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this product?")) {
      deleteProduct(id);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="border-b bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <Logo size="sm" />
            <span className="text-2xl font-serif font-bold text-slate-800">Jewelry Doctor - Admin</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/admin/settings">
              <Button variant="outline" size="sm">
                ⚙️ Settings
              </Button>
            </Link>
            <Link href="/">
              <Button variant="outline" size="sm">
                View Website
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-serif font-bold text-slate-800">
            Product Management
          </h1>
          <Link href="/admin/product/new">
            <Button size="lg">
              + Add New Product
            </Button>
          </Link>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden">
              <div className="relative aspect-square bg-slate-100">
                <Image
                  src={product.images[0]}
                  alt={product.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-5 space-y-4">
                <div>
                  <p className="text-sm font-medium text-amber-700 mb-2">
                    # {product.id}
                  </p>
                  <h3 className="font-semibold text-slate-800 line-clamp-2">
                    {product.name}
                  </h3>
                  <p className="text-sm text-slate-600 mt-1">
                    Shape: {product.shape}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Link href={`/admin/product/${product.id}`} className="flex-1">
                    <Button variant="outline" className="w-full">
                      Edit
                    </Button>
                  </Link>
                  <Button
                    variant="destructive"
                    onClick={() => handleDelete(product.id)}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {products.length === 0 && (
          <div className="text-center py-12">
            <p className="text-slate-500 text-lg">No products yet. Add your first product!</p>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
