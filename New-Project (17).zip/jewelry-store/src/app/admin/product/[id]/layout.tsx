import { products } from "@/lib/products";

export async function generateStaticParams() {
  return [...products.map((product) => ({
    id: product.id,
  })), { id: 'new' }];
}

export default function AdminProductLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
