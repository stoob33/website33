"use client";

import { useEffect, useState, use } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";
import { useProducts } from "@/lib/products-store";
import { Product } from "@/lib/products";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import Logo from "@/components/Logo";
import Footer from "@/components/Footer";

export const dynamicParams = false;

export default function ProductEditPage({ params }: { params: Promise<{ id: string }> }) {
  const { isAdmin, isLoading } = useAuth();
  const { getProductById, updateProduct, addProduct } = useProducts();
  const router = useRouter();
  const resolvedParams = use(params);
  const isNew = resolvedParams.id === "new";

  const [formData, setFormData] = useState<Product>({
    id: "",
    name: "",
    description: "",
    images: ["", "", "", ""],
    metal: {
      options: ["14k White Gold"],
      default: "14k White Gold"
    },
    shape: "ROUND",
    color: {
      options: ["D-F"],
      default: "D-F"
    },
    clarity: {
      options: ["VS"],
      default: "VS"
    },
    weight: {
      options: ["2.41 ct."],
      default: "2.41 ct."
    },
    prices: {
      "2.41 ct.": 0
    }
  });

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    console.log("Form submitted!");
    console.log("Saving product...", formData);
    console.log("Is new?", isNew);

    // Validate required fields
    if (!formData.id || !formData.name) {
      alert("Please fill in Product ID and Name");
      return;
    }

    // Save the product
    if (isNew) {
      console.log("Adding new product...");
      addProduct(formData);
      alert("Product created successfully!");
    } else {
      console.log("Updating existing product...");
      updateProduct(resolvedParams.id, formData);
      alert("Product updated successfully!");
    }

    // Navigate back to admin
    setTimeout(() => {
      router.push("/admin");
    }, 300);
  };

  const handleImageChange = (index: number, value: string) => {
    const newImages = [...formData.images];
    newImages[index] = value;
    setFormData({ ...formData, images: newImages });
  };

  const handleMetalOptionChange = (index: number, value: string) => {
    setFormData((prevData) => {
      const newOptions = [...prevData.metal.options];
      newOptions[index] = value;
      return {
        ...prevData,
        metal: { ...prevData.metal, options: newOptions }
      };
    });
  };

  const handleWeightOptionChange = (index: number, value: string) => {
    setFormData((prevData) => {
      const newOptions = [...prevData.weight.options];
      const oldWeight = newOptions[index];
      newOptions[index] = value;

      // Update prices object with new weight key
      const newPrices = { ...prevData.prices };
      if (oldWeight !== value && newPrices[oldWeight] !== undefined) {
        newPrices[value] = newPrices[oldWeight];
        delete newPrices[oldWeight];
      }

      return {
        ...prevData,
        weight: { ...prevData.weight, options: newOptions },
        prices: newPrices
      };
    });
  };

  const handlePriceChange = (weight: string, price: number) => {
    setFormData((prevData) => ({
      ...prevData,
      prices: { ...prevData.prices, [weight]: price }
    }));
  };

  const handleImageUpload = (index: number, file: File) => {
    console.log(`Image ${index} upload started`, file);
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        console.log(`Image ${index} loaded successfully`);
        setFormData((prevData) => {
          const newImages = [...prevData.images];
          newImages[index] = reader.result as string;
          console.log(`Image ${index} set in formData`, newImages);
          return { ...prevData, images: newImages };
        });
      };
      reader.onerror = () => {
        console.error(`Error loading image ${index}`);
      };
      reader.readAsDataURL(file);
    } else {
      console.error(`Invalid file type for image ${index}:`, file?.type);
    }
  };

  const addMetalOption = () => {
    setFormData((prevData) => ({
      ...prevData,
      metal: {
        ...prevData.metal,
        options: [...prevData.metal.options, ""]
      }
    }));
  };

  const removeMetalOption = (index: number) => {
    setFormData((prevData) => {
      const newOptions = prevData.metal.options.filter((_, i) => i !== index);
      return {
        ...prevData,
        metal: {
          ...prevData.metal,
          options: newOptions,
          default: newOptions.includes(prevData.metal.default) ? newOptions[0] : newOptions[0]
        }
      };
    });
  };

  const addWeightOption = () => {
    const newWeight = "";
    setFormData((prevData) => ({
      ...prevData,
      weight: {
        ...prevData.weight,
        options: [...prevData.weight.options, newWeight]
      },
      prices: {
        ...prevData.prices,
        [newWeight]: 0
      }
    }));
  };

  const removeWeightOption = (index: number) => {
    setFormData((prevData) => {
      const weightToRemove = prevData.weight.options[index];
      const newOptions = prevData.weight.options.filter((_, i) => i !== index);
      const newPrices = { ...prevData.prices };
      delete newPrices[weightToRemove];

      return {
        ...prevData,
        weight: {
          ...prevData.weight,
          options: newOptions,
          default: newOptions.includes(prevData.weight.default) ? newOptions[0] : newOptions[0]
        },
        prices: newPrices
      };
    });
  };

  // Load existing product data
  useEffect(() => {
    if (!isLoading && !isAdmin) {
      router.push("/");
      return;
    }

    if (!isNew && !isLoading) {
      const product = getProductById(resolvedParams.id);
      if (product) {
        setFormData(product);
      } else {
        router.push("/admin");
      }
    }
  }, [isAdmin, isLoading, isNew, resolvedParams.id, getProductById, router]);

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-slate-600">Loading...</p>
      </div>
    );
  }

  // Check admin access
  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="border-b bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <Logo size="sm" />
            <span className="text-2xl font-serif font-bold text-slate-800">Jewelry Doctor - Admin</span>
          </Link>
          <Link href="/admin">
            <Button variant="outline" size="sm">
              ← Back to Dashboard
            </Button>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12 max-w-4xl">
        <h1 className="text-4xl font-serif font-bold text-slate-800 mb-8">
          {isNew ? "Add New Product" : "Edit Product"}
        </h1>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Info */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Basic Information</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="id">Product ID</Label>
                <Input
                  id="id"
                  value={formData.id}
                  onChange={(e) => setFormData({ ...formData, id: e.target.value })}
                  placeholder="LG2224P-RD-20"
                  required
                  disabled={!isNew}
                />
              </div>

              <div>
                <Label htmlFor="name">Product Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="14K White Gold Lab Grown Diamond..."
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="This eye-catching wedding is available in..."
                  rows={4}
                  required
                />
              </div>

              <div>
                <Label htmlFor="shape">Shape</Label>
                <select
                  id="shape"
                  value={formData.shape}
                  onChange={(e) => setFormData({ ...formData, shape: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md"
                  required
                >
                  <option value="ROUND">ROUND</option>
                  <option value="PEAR">PEAR</option>
                  <option value="OVAL">OVAL</option>
                  <option value="EMERALD">EMERALD</option>
                </select>
              </div>
            </div>
          </Card>

          {/* Images */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Product Images (4 images)</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {formData.images.map((image, index) => (
                <div key={index} className="space-y-3">
                  <Label htmlFor={`image-${index}`}>Image {index + 1}</Label>

                  {/* File Upload */}
                  <div>
                    <Label
                      htmlFor={`file-${index}`}
                      className="cursor-pointer inline-flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-md text-sm font-medium transition-colors"
                    >
                      📤 Upload Image
                    </Label>
                    <input
                      id={`file-${index}`}
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleImageUpload(index, file);
                      }}
                      className="hidden"
                    />
                  </div>

                  {/* OR URL Input */}
                  <div>
                    <Label htmlFor={`url-${index}`} className="text-xs text-slate-500">Or enter URL:</Label>
                    <Input
                      id={`url-${index}`}
                      value={image.startsWith('data:') ? '' : image}
                      onChange={(e) => handleImageChange(index, e.target.value)}
                      placeholder="https://images.unsplash.com/..."
                      className="text-sm"
                    />
                  </div>

                  {/* Preview */}
                  {image && (
                    <div className="relative aspect-square bg-slate-100 rounded-lg overflow-hidden border-2 border-slate-200">
                      <img
                        src={image}
                        alt={`Preview ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() => handleImageChange(index, '')}
                        className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-red-600"
                      >
                        ×
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
            <p className="text-sm text-slate-500 mt-4">
              💡 Tip: You can upload images directly from your computer or paste image URLs
            </p>
          </Card>

          {/* Metal Options */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Metal Options</h2>
              <Button type="button" onClick={addMetalOption} variant="outline" size="sm">
                + Add Metal
              </Button>
            </div>
            <div className="space-y-4">
              {formData.metal.options.map((option, index) => (
                <div key={index} className="flex gap-2">
                  <div className="flex-1">
                    <Label htmlFor={`metal-${index}`}>Metal Option {index + 1}</Label>
                    <Input
                      id={`metal-${index}`}
                      value={option}
                      onChange={(e) => handleMetalOptionChange(index, e.target.value)}
                      placeholder="14k White Gold"
                      required
                    />
                  </div>
                  {formData.metal.options.length > 1 && (
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      onClick={() => removeMetalOption(index)}
                      className="mt-8"
                    >
                      Remove
                    </Button>
                  )}
                </div>
              ))}
              <div>
                <Label htmlFor="metal-default">Default Metal</Label>
                <select
                  id="metal-default"
                  value={formData.metal.default}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      metal: { ...formData.metal, default: e.target.value }
                    })
                  }
                  className="w-full px-3 py-2 border border-slate-300 rounded-md"
                >
                  {formData.metal.options.filter(o => o).map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </Card>

          {/* Weight Options */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Weight Options</h2>
              <Button type="button" onClick={addWeightOption} variant="outline" size="sm">
                + Add Weight
              </Button>
            </div>
            <div className="space-y-4">
              {formData.weight.options.map((option, index) => (
                <div key={index} className="flex gap-2">
                  <div className="flex-1">
                    <Label htmlFor={`weight-${index}`}>Weight Option {index + 1}</Label>
                    <Input
                      id={`weight-${index}`}
                      value={option}
                      onChange={(e) => handleWeightOptionChange(index, e.target.value)}
                      placeholder="2.41 ct."
                      required
                    />
                  </div>
                  {formData.weight.options.length > 1 && (
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      onClick={() => removeWeightOption(index)}
                      className="mt-8"
                    >
                      Remove
                    </Button>
                  )}
                </div>
              ))}
              <div>
                <Label htmlFor="weight-default">Default Weight</Label>
                <select
                  id="weight-default"
                  value={formData.weight.default}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      weight: { ...formData.weight, default: e.target.value }
                    })
                  }
                  className="w-full px-3 py-2 border border-slate-300 rounded-md"
                >
                  {formData.weight.options.filter(o => o).map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </Card>

          {/* Pricing */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Pricing</h2>
            <div className="space-y-4">
              {formData.weight.options.filter(w => w).map((weight) => (
                <div key={weight}>
                  <Label htmlFor={`price-${weight}`}>
                    {formData.weight.options.length === 1 ? "Price" : `Price for ${weight}`}
                  </Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">$</span>
                    <Input
                      id={`price-${weight}`}
                      type="number"
                      value={formData.prices[weight] || 0}
                      onChange={(e) => handlePriceChange(weight, parseFloat(e.target.value) || 0)}
                      placeholder="2500"
                      className="pl-7"
                      required
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>
              ))}
            </div>
            <p className="text-sm text-slate-500 mt-4">
              {formData.weight.options.length === 1
                ? "Set your product price."
                : "Set the price for each carat weight. Prices will update automatically when customers select different weights."}
            </p>
          </Card>

          {/* Submit Buttons */}
          <div className="flex gap-4">
            <Button type="submit" size="lg" className="flex-1">
              {isNew ? "Create Product" : "Save Changes"}
            </Button>
            <Link href="/admin" className="flex-1">
              <Button type="button" variant="outline" size="lg" className="w-full">
                Cancel
              </Button>
            </Link>
          </div>
        </form>
      </main>

      <Footer />
    </div>
  );
}
