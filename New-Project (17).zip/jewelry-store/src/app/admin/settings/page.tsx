"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";
import { useSettings } from "@/lib/settings-store";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import Logo from "@/components/Logo";
import Footer from "@/components/Footer";

export default function SettingsPage() {
  const { isAdmin, isLoading } = useAuth();
  const { settings, updateSettings } = useSettings();
  const router = useRouter();

  const [description, setDescription] = useState(settings.description);
  const [subtitle, setSubtitle] = useState(settings.subtitle);

  useEffect(() => {
    if (!isLoading && !isAdmin) {
      router.push("/");
    }
  }, [isAdmin, isLoading, router]);

  useEffect(() => {
    setDescription(settings.description);
    setSubtitle(settings.subtitle);
  }, [settings]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-slate-600">Loading...</p>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({ description, subtitle });
    alert("Settings saved successfully!");
    router.push("/admin");
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="border-b bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <Logo size="sm" />
            <span className="text-2xl font-serif font-bold text-slate-800">Jewelry Doctor - Admin</span>
          </Link>
          <Link href="/admin">
            <Button variant="outline" size="sm">
              ← Back to Dashboard
            </Button>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12 max-w-3xl">
        <h1 className="text-4xl font-serif font-bold text-slate-800 mb-8">
          Homepage Settings
        </h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Homepage Content */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Homepage Content</h2>
            <div className="space-y-6">
              <div>
                <Label htmlFor="description">Main Description</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                  className="mt-2"
                  placeholder="Discover exquisite lab-grown diamond engagement rings..."
                />
                <p className="text-sm text-slate-500 mt-2">
                  This appears on the homepage below the logo
                </p>
              </div>

              <div>
                <Label htmlFor="subtitle">Subtitle</Label>
                <Textarea
                  id="subtitle"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  rows={2}
                  className="mt-2"
                  placeholder="Premium quality, ethically sourced..."
                />
                <p className="text-sm text-slate-500 mt-2">
                  This appears below the main description
                </p>
              </div>
            </div>
          </Card>

          <div className="flex gap-4">
            <Button type="submit" size="lg" className="flex-1">
              Save Settings
            </Button>
            <Link href="/admin" className="flex-1">
              <Button type="button" variant="outline" size="lg" className="w-full">
                Cancel
              </Button>
            </Link>
          </div>
        </form>
      </main>

      <Footer />
    </div>
  );
}
