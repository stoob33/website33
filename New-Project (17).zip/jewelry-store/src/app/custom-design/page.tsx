"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Image from "next/image";
import { useProducts } from "@/lib/products-store";
import Logo from "@/components/Logo";
import AdminLogin from "@/components/AdminLogin";
import Footer from "@/components/Footer";

const metals = [
  { label: "14W", value: "14w", color: "bg-slate-300" },
  { label: "14Y", value: "14y", color: "bg-amber-400" }
];

export default function CustomDesign() {
  const { products, isLoading } = useProducts();

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <Logo size="sm" />
            <span className="text-2xl font-serif font-bold text-slate-800">Jewelry Doctor</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="outline" size="sm">
                ← Back to Home
              </Button>
            </Link>
            <AdminLogin />
          </div>
        </div>
      </header>

      {/* Products Grid */}
      <main className="container mx-auto px-6 py-12">
        <h1 className="text-4xl font-serif font-bold text-slate-800 mb-8 text-center">
          Custom Design Collection
        </h1>

        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-xl text-slate-600">Loading products...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.map((product) => (
            <Link key={product.id} href={`/product/${product.id}`}>
              <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer">
                {/* Product Image */}
                <div className="relative aspect-square bg-slate-50">
                  <Image
                    src={product.images[0]}
                    alt={product.name}
                    fill
                    className="object-cover"
                  />
                </div>

                {/* Product Details */}
                <div className="p-5 space-y-4">
                  {/* Product ID */}
                  <p className="text-sm font-medium text-amber-700">
                    # {product.id}
                  </p>

                  {/* Product Name */}
                  <h3 className="text-sm text-slate-700 line-clamp-3 min-h-[3.6rem]">
                    {product.name}
                  </h3>

                  {/* Metal Options */}
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-slate-600">Metal:</p>
                    <div className="flex gap-2">
                      {metals.map((metal) => (
                        <div
                          key={metal.value}
                          className="w-10 h-10 rounded-full border-2 border-slate-300 flex items-center justify-center"
                        >
                          <div className={`w-8 h-8 rounded-full ${metal.color} flex items-center justify-center`}>
                            <span className="text-xs font-semibold text-slate-700">{metal.label}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Carat Options */}
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-slate-600">Carat:</p>
                    <div className="flex gap-2">
                      {product.weight.options.map((weight) => (
                        <div
                          key={weight}
                          className="px-3 py-1 bg-slate-200 text-slate-700 text-sm font-medium rounded"
                        >
                          {weight.replace(" ct.", "")}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
