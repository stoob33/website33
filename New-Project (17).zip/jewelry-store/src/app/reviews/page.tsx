"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Logo from "@/components/Logo";
import AdminLogin from "@/components/AdminLogin";
import Footer from "@/components/Footer";

export default function Reviews() {
  // Real Google reviews from Jewelry Doctor
  const reviews = [
    {
      name: "Marina",
      rating: 5,
      date: "Recent",
      text: "Excellent service. Done in an hour. Sophie was amazing!",
      avatar: "M"
    },
    {
      name: "Corey",
      rating: 5,
      date: "Recent",
      text: "This gentlemen did amazing work!!",
      avatar: "C"
    },
    {
      name: "Joani",
      rating: 5,
      date: "Recent",
      text: "Ali and his staff are wonderful! This is the 3rd time I have been there for jewelry repairs. They are helpful and friendly! It is always done same day, within an hour or so. They always clean my rings when I am there, even if that is not the piece being worked on. I trust Ali's judgement and they have the best prices around! I will not go anywhere else for my jewerly repair needs. Thanks Ali!.",
      avatar: "J"
    },
    {
      name: "Laurie",
      rating: 5,
      date: "Recent",
      text: "My husband needed a repair done on his 31 year old wedding band. We were in the neighborhood and decided to stop by. Sofia fixed and polished his ring and it looks better than the day we bought it. We are repeat customers and they are the only place we go for our jewelry repairs. They are fast, affordable, and their work is amazing. Thanks again!.",
      avatar: "L"
    },
    {
      name: "Justin",
      rating: 5,
      date: "Recent",
      text: "These guys are great. They were able to get my G-Shock watch up and running in 10 min. Highly recommend!.",
      avatar: "J"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <Logo size="sm" />
            <span className="text-2xl font-serif font-bold text-slate-800">Jewelry Doctor</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="outline" size="sm">
                ← Back to Home
              </Button>
            </Link>
            <AdminLogin />
          </div>
        </div>
      </header>

      {/* Reviews Content */}
      <main className="container mx-auto px-6 py-12 max-w-4xl">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-serif font-bold text-slate-800 mb-4">
            Customer Reviews
          </h1>
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <span key={star} className="text-3xl text-yellow-400">⭐</span>
              ))}
            </div>
            <span className="text-2xl font-semibold text-slate-700">4.9</span>
          </div>
          <p className="text-slate-600">Based on 500+ Google reviews</p>
        </div>

        {/* Reviews Grid */}
        <div className="space-y-6">
          {reviews.map((review, index) => (
            <Card key={index} className="p-6 bg-white">
              <div className="flex items-start gap-4">
                {/* Avatar */}
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold">{review.avatar}</span>
                </div>

                {/* Review Content */}
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-slate-800">{review.name}</h3>
                    <span className="text-sm text-slate-500">{review.date}</span>
                  </div>

                  {/* Stars */}
                  <div className="flex mb-3">
                    {[...Array(review.rating)].map((_, i) => (
                      <span key={i} className="text-yellow-400 text-lg">⭐</span>
                    ))}
                  </div>

                  {/* Review Text */}
                  <p className="text-slate-600 leading-relaxed">{review.text}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Google Reviews Link */}
        <div className="mt-12 text-center">
          <p className="text-slate-600 mb-4">Want to see all 548 reviews?</p>
          <a
            href="https://www.google.com/search?q=jewelry+doctor+orem"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block"
          >
            <Button size="lg" variant="outline">
              View All Google Reviews →
            </Button>
          </a>
        </div>
      </main>

      <Footer />
    </div>
  );
}
