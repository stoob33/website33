"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import Logo from "@/components/Logo";
import AdminLogin from "@/components/AdminLogin";
import Footer from "@/components/Footer";
import { useSettings } from "@/lib/settings-store";

export default function Home() {
  const { settings } = useSettings();
  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      {/* Admin Login Button - Top Right */}
      <div className="absolute top-6 right-6 z-10">
        <AdminLogin />
      </div>

      <div className="flex-1 flex items-center justify-center">
        <div className="max-w-2xl mx-auto px-6 text-center space-y-8 py-12">
          {/* Logo Area */}
          <div className="space-y-4">
            <Logo size="md" className="mx-auto" />
            <h1 className="text-5xl font-serif font-bold text-slate-800">
              Jewelry Doctor
            </h1>
          </div>

          {/* Message */}
          <div className="space-y-4">
            <p className="text-xl text-slate-600 leading-relaxed">
              {settings.description}
            </p>
            <p className="text-lg text-slate-500">
              {settings.subtitle}
            </p>
          </div>

          {/* Buttons */}
          <div className="pt-4 flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/custom-design">
              <Button
                size="lg"
                className="text-lg px-8 py-6 bg-gradient-to-r from-amber-600 to-rose-600 hover:from-amber-700 hover:to-rose-700 shadow-xl"
              >
                Custom Design
              </Button>
            </Link>
            <Link href="/reviews">
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-6 border-2 border-amber-600 text-amber-700 hover:bg-amber-50 shadow-xl"
              >
                ⭐ Reviews
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
