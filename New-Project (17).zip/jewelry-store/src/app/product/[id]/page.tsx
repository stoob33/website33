"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Image from "next/image";
import { useState, use, useEffect } from "react";
import { useProducts } from "@/lib/products-store";
import { notFound } from "next/navigation";
import Logo from "@/components/Logo";
import AdminLogin from "@/components/AdminLogin";
import Footer from "@/components/Footer";

export const dynamicParams = false;

export default function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { getProductById, isLoading } = useProducts();
  const resolvedParams = use(params);
  const product = getProductById(resolvedParams.id);

  const [selectedMetal, setSelectedMetal] = useState("");
  const [selectedColor, setSelectedColor] = useState("");
  const [selectedClarity, setSelectedClarity] = useState("");
  const [selectedWeight, setSelectedWeight] = useState("");
  const [mainImage, setMainImage] = useState(0);

  // Initialize state when product loads
  useEffect(() => {
    if (product) {
      setSelectedMetal(product.metal.default);
      setSelectedColor(product.color.default);
      setSelectedClarity(product.clarity.default);
      setSelectedWeight(product.weight.default);
    }
  }, [product]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-slate-600">Loading...</p>
      </div>
    );
  }

  if (!product) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <Logo size="sm" />
            <span className="text-2xl font-serif font-bold text-slate-800">Jewelry Doctor</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/custom-design">
              <Button variant="outline" size="sm">
                ← Back to Gallery
              </Button>
            </Link>
            <AdminLogin />
          </div>
        </div>
      </header>

      {/* Product Detail */}
      <main className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Image Gallery */}
          <div className="space-y-4">
            {/* Main Image */}
            <Card className="overflow-hidden">
              <div className="relative aspect-square bg-slate-50">
                <Image
                  src={product.images[mainImage]}
                  alt={product.name}
                  fill
                  className="object-cover"
                />
              </div>
            </Card>

            {/* Thumbnail Images */}
            <div className="grid grid-cols-4 gap-3">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setMainImage(index)}
                  className={`relative aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                    mainImage === index
                      ? "border-amber-600 shadow-lg scale-105"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <Image
                    src={image}
                    alt={`${product.name} view ${index + 1}`}
                    fill
                    className="object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info & Options */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-serif font-bold text-slate-800 mb-4">
                {product.name}
              </h1>
              <p className="text-slate-600 leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Item Number */}
            <div className="border-t pt-6">
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium text-slate-600">Item #:</span>
                <span className="text-sm font-semibold text-amber-700">{product.id}</span>
              </div>
            </div>

            {/* Metal Options */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-slate-700">Metal:</label>
              <div className="flex flex-wrap gap-3">
                {product.metal.options.map((metal) => (
                  <button
                    key={metal}
                    onClick={() => setSelectedMetal(metal)}
                    className={`px-5 py-2.5 rounded-md text-sm font-medium transition-all ${
                      selectedMetal === metal
                        ? "bg-purple-800 text-white shadow-lg"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300"
                    }`}
                  >
                    {metal}
                  </button>
                ))}
              </div>
            </div>

            {/* Shape (Fixed) */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-slate-700">Shape:</label>
              <div className="flex flex-wrap gap-3">
                <button
                  className="px-5 py-2.5 rounded-md text-sm font-medium bg-purple-800 text-white shadow-lg"
                >
                  {product.shape}
                </button>
              </div>
            </div>

            {/* Color Options */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-slate-700">Color:</label>
              <div className="flex flex-wrap gap-3">
                {product.color.options.map((color) => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`px-5 py-2.5 rounded-md text-sm font-medium transition-all ${
                      selectedColor === color
                        ? "bg-purple-800 text-white shadow-lg"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300"
                    }`}
                  >
                    {color}
                  </button>
                ))}
              </div>
            </div>

            {/* Clarity Options */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-slate-700">Clarity:</label>
              <div className="flex flex-wrap gap-3">
                {product.clarity.options.map((clarity) => (
                  <button
                    key={clarity}
                    onClick={() => setSelectedClarity(clarity)}
                    className={`px-5 py-2.5 rounded-md text-sm font-medium transition-all ${
                      selectedClarity === clarity
                        ? "bg-purple-800 text-white shadow-lg"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300"
                    }`}
                  >
                    {clarity}
                  </button>
                ))}
              </div>
            </div>

            {/* Weight Options */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-slate-700">Weight:</label>
              <div className="flex flex-wrap gap-3">
                {product.weight.options.map((weight) => (
                  <button
                    key={weight}
                    onClick={() => setSelectedWeight(weight)}
                    className={`px-5 py-2.5 rounded-md text-sm font-medium transition-all ${
                      selectedWeight === weight
                        ? "bg-purple-800 text-white shadow-lg"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300"
                    }`}
                  >
                    {weight}
                  </button>
                ))}
              </div>
            </div>

            {/* Price */}
            <div className="pt-6 border-t">
              <div className="mb-4">
                <p className="text-sm text-slate-600 mb-1">Price:</p>
                <p className="text-4xl font-bold text-slate-800">
                  ${selectedWeight && product.prices && product.prices[selectedWeight]
                    ? product.prices[selectedWeight].toLocaleString('en-US')
                    : '0'}
                </p>
              </div>

              {/* Call for Availability */}
              <div className="from-amber-50 to-rose-50 border-2 border-amber-200 rounded-lg p-6 text-center bg-[#f3f4f6]">
                <p className="text-lg font-semibold text-slate-800 mb-3">
                  For availability, call us:
                </p>
                <a
                  href="tel:8012264225"
                  className="inline-flex items-center gap-2 text-2xl font-bold text-amber-700 hover:text-amber-800 transition-colors"
                >
                  📞 (801) 226-4225
                </a>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
