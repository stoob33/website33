"use client";

import { useEffect } from "react";
import { AuthProvider } from "@/lib/auth";
import { ProductsProvider } from "@/lib/products-store";
import { SettingsProvider } from "@/lib/settings-store";

export default function ClientBody({
  children,
}: {
  children: React.ReactNode;
}) {
  // Remove any extension-added classes during hydration
  useEffect(() => {
    // This runs only on the client after hydration
    document.body.className = "antialiased";
  }, []);

  return (
    <div className="antialiased">
      <AuthProvider>
        <SettingsProvider>
          <ProductsProvider>
            {children}
          </ProductsProvider>
        </SettingsProvider>
      </AuthProvider>
    </div>
  );
}
