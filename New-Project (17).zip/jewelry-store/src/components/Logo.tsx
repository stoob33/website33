import Image from "next/image";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  className?: string;
}

export default function Logo({ size = "md", className = "" }: LogoProps) {
  const sizes = {
    sm: { width: 100, height: 100 },
    md: { width: 200, height: 200 },
    lg: { width: 280, height: 280 }
  };

  const currentSize = sizes[size];

  return (
    <div className={`${className} flex items-center justify-center`}>
      <Image
        src="/logo.png"
        alt="Jewelry Doctor Logo"
        width={currentSize.width}
        height={currentSize.height}
        className="object-contain"
        priority
      />
    </div>
  );
}
