# Deploy to GitHub Pages

This site is configured for automatic deployment to GitHub Pages using GitHub Actions.

## 🚀 Quick Setup

**Option 1: Use Setup Script (Recommended)**
```bash
./setup-github-pages.sh
```
This interactive script will configure everything for you based on your deployment type.

**Option 2: Manual Setup**
Follow the steps below for your deployment type.

## Automatic Deployment (Recommended)

1. **Create a GitHub Repository**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
   git push -u origin main
   ```

2. **Enable GitHub Pages**
   - Go to your repository on GitHub
   - Click on **Settings** > **Pages**
   - Under **Source**, select **GitHub Actions**
   - The workflow will automatically deploy on every push to the `main` branch

3. **Access Your Site**
   - **Option A: Custom Domain** → `https://yourdomain.com/`
   - **Option B: GitHub Subdirectory** → `https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/`
   - **Option C: User Site** → `https://YOUR_USERNAME.github.io/` (only if repo is named `YOUR_USERNAME.github.io`)

## Custom Domain Setup

1. **Add CNAME Record**
   - Go to your domain registrar (GoDaddy, Namecheap, etc.)
   - Add a CNAME record pointing to `YOUR_USERNAME.github.io`
   - Or add an A record pointing to GitHub's IPs:
     - `185.199.108.153`
     - `185.199.109.153`
     - `185.199.110.153`
     - `185.199.111.153`

2. **Configure in GitHub**
   - Go to Settings > Pages
   - Under "Custom domain", enter your domain (e.g., `jewelrydoctor.com`)
   - Check "Enforce HTTPS" (wait a few minutes for SSL)

3. **Create CNAME file**
   Create a file named `CNAME` in the `public/` folder with your domain:
   ```
   yourdomain.com
   ```

## Subdirectory Deployment (username.github.io/repo-name)

If your site will be at `https://username.github.io/repo-name/`, you need to set the basePath:

1. **Update next.config.js**
   ```javascript
   basePath: '/YOUR_REPO_NAME',
   ```

2. **Rebuild and deploy**
   ```bash
   bun run build
   git add .
   git commit -m "Add basePath"
   git push
   ```

## Manual Deployment

If you prefer to deploy manually:

1. **Build the site**
   ```bash
   bun run build
   ```

2. **Deploy the `out` folder**
   - Upload the contents of the `out` folder to your GitHub Pages repository
   - Or use GitHub Desktop to commit and push the `out` folder

## Troubleshooting

### "This site can't be reached" or "Not working"

**For Custom Domains:**
1. **Wait for DNS propagation** (can take 24-48 hours)
2. **Check DNS settings** at your registrar:
   - CNAME record should point to `YOUR_USERNAME.github.io`
   - Or A records should point to GitHub's IPs
3. **Verify CNAME file** exists in `public/CNAME` with your domain name
4. **Check GitHub Pages settings** - custom domain should show green checkmark
5. **Try without https first**, then enable "Enforce HTTPS" after it works

**For Subdirectory URLs (username.github.io/repo-name):**
1. **Add basePath to next.config.js**:
   ```javascript
   basePath: '/your-repo-name',
   ```
2. **Rebuild**: `bun run build`
3. **Commit and push**: The workflow will redeploy

**For User Sites (username.github.io):**
1. Repository MUST be named exactly `username.github.io`
2. No basePath needed
3. Deploy from `main` branch

### Images not loading
- Make sure all image URLs are absolute or properly referenced
- Check that imgur.com images are accessible
- Verify Next.js Image component has `unoptimized: true`

### 404 errors on page refresh
- Added `trailingSlash: true` in next.config.js to help with this
- GitHub Pages serves static files, so all routes must be pre-generated

### Build fails in GitHub Actions
- Check the Actions tab in your repository for error logs
- Ensure all dependencies are listed in `package.json`
- Verify that the Node.js version in the workflow matches your local version

### Blank page or JavaScript errors
1. Check browser console for errors
2. If using subdirectory, make sure basePath is set correctly
3. Clear browser cache and hard refresh (Ctrl+Shift+R)

## Local Testing

To test the static export locally:

```bash
# Build the site
bun run build

# Serve the out directory
bunx serve out
```

Then visit `http://localhost:3000` to see your static site.
