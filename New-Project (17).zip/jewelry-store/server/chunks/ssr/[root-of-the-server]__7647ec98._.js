module.exports = {

"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[project]/src/lib/auth.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "AuthProvider": (()=>AuthProvider),
    "useAuth": (()=>useAuth)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function AuthProvider({ children }) {
    const [isAdmin, setIsAdmin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // Check if user is already logged in
        const adminStatus = localStorage.getItem("isAdmin");
        if (adminStatus === "true") {
            setIsAdmin(true);
        }
        setIsLoading(false);
    }, []);
    const login = (username, password)=>{
        // Simple authentication - you can replace with a real API call
        if (username === "admin" && password === "admin123") {
            setIsAdmin(true);
            localStorage.setItem("isAdmin", "true");
            return true;
        }
        return false;
    };
    const logout = ()=>{
        setIsAdmin(false);
        localStorage.removeItem("isAdmin");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            isAdmin,
            isLoading,
            login,
            logout
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/lib/auth.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
function useAuth() {
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (context === undefined) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
}
}}),
"[project]/src/lib/products.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getProductById": (()=>getProductById),
    "products": (()=>products)
});
const products = [
    {
        id: "LG2224P-RD-20",
        name: "14K White Gold Lab Grown Diamond 2 3/8 Ct.Tw. Round Hidden Halo Engagement Ring (IGI Certified Center 2ct)",
        description: "This eye-catching wedding is available in 14k White Gold. There are 34 round diamonds with a total carat weight of 2.41ct set in a Micro Prong setting.",
        images: [
            "https://i.imgur.com/uTUnuSC.jpg",
            "https://i.imgur.com/SJioxBF.jpg",
            "https://i.imgur.com/bd9laNB.jpg",
            "https://i.imgur.com/awCuWmv.jpg"
        ],
        metal: {
            options: [
                "14k White Gold",
                "14k Yellow Gold"
            ],
            default: "14k White Gold"
        },
        shape: "ROUND",
        color: {
            options: [
                "D-F"
            ],
            default: "D-F"
        },
        clarity: {
            options: [
                "VS"
            ],
            default: "VS"
        },
        weight: {
            options: [
                "2.41 ct.",
                "3.42 ct.",
                "4.54 ct."
            ],
            default: "2.41 ct."
        },
        prices: {
            "2.41 ct.": 2500,
            "3.42 ct.": 3800,
            "4.54 ct.": 5200
        }
    },
    {
        id: "LG2224W-PE-20",
        name: "14K White Gold Lab Grown Diamond 2 3/8 Ct.Tw. Pear Hidden Halo Engagement Ring",
        description: "This eye-catching wedding is available in 14k White Gold. There are 34 round diamonds with a total carat weight of 2.41ct set in a Micro Prong setting.",
        images: [
            "https://i.imgur.com/8EKCQFh.jpg",
            "https://i.imgur.com/8Z123JP.jpg",
            "https://i.imgur.com/h5chKGf.jpg",
            "https://i.imgur.com/5xpSOki.jpg"
        ],
        metal: {
            options: [
                "14k White Gold",
                "14k Yellow Gold"
            ],
            default: "14k White Gold"
        },
        shape: "PEAR",
        color: {
            options: [
                "D-F"
            ],
            default: "D-F"
        },
        clarity: {
            options: [
                "VS"
            ],
            default: "VS"
        },
        weight: {
            options: [
                "2.41 ct.",
                "3.42 ct.",
                "4.54 ct."
            ],
            default: "2.41 ct."
        },
        prices: {
            "2.41 ct.": 2500,
            "3.42 ct.": 3800,
            "4.54 ct.": 5200
        }
    },
    {
        id: "LG2224W-OV-20",
        name: "14K White Gold Lab Grown Diamond 2 3/8 Ct.Tw. Oval Hidden Halo Engagement Ring",
        description: "This eye-catching wedding is available in 14k White Gold. There are 34 round diamonds with a total carat weight of 2.41ct set in a Micro Prong setting.",
        images: [
            "https://i.imgur.com/tpvlLhJ.jpg",
            "https://i.imgur.com/A9nQPWc.jpg",
            "https://i.imgur.com/RBZbcZO.jpg",
            "https://i.imgur.com/NVewFhM.jpg"
        ],
        metal: {
            options: [
                "14k White Gold",
                "14k Yellow Gold"
            ],
            default: "14k White Gold"
        },
        shape: "OVAL",
        color: {
            options: [
                "D-F"
            ],
            default: "D-F"
        },
        clarity: {
            options: [
                "VS"
            ],
            default: "VS"
        },
        weight: {
            options: [
                "2.41 ct.",
                "3.42 ct.",
                "4.54 ct."
            ],
            default: "2.41 ct."
        },
        prices: {
            "2.41 ct.": 2500,
            "3.42 ct.": 3800,
            "4.54 ct.": 5200
        }
    },
    {
        id: "LG2224W-EM-20",
        name: "14K White Gold Lab Grown Diamond 2 3/8 Ct.Tw. Emerald Hidden Halo Engagement Ring",
        description: "This eye-catching wedding is available in 14k White Gold. There are 34 round diamonds with a total carat weight of 2.41ct set in a Micro Prong setting.",
        images: [
            "https://i.imgur.com/zoxA1ey.jpg",
            "https://i.imgur.com/7g3hKO5.jpg",
            "https://i.imgur.com/cKKu4PG.jpg",
            "https://i.imgur.com/R3b53xN.jpg"
        ],
        metal: {
            options: [
                "14k White Gold",
                "14k Yellow Gold"
            ],
            default: "14k White Gold"
        },
        shape: "EMERALD",
        color: {
            options: [
                "D-F"
            ],
            default: "D-F"
        },
        clarity: {
            options: [
                "VS"
            ],
            default: "VS"
        },
        weight: {
            options: [
                "2.41 ct.",
                "3.42 ct.",
                "4.54 ct."
            ],
            default: "2.41 ct."
        },
        prices: {
            "2.41 ct.": 2500,
            "3.42 ct.": 3800,
            "4.54 ct.": 5200
        }
    }
];
function getProductById(id) {
    return products.find((p)=>p.id === id);
}
}}),
"[project]/src/lib/products-store.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ProductsProvider": (()=>ProductsProvider),
    "useProducts": (()=>useProducts)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$products$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/products.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
const ProductsContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function ProductsProvider({ children }) {
    const [products, setProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // Load products from localStorage or use initial products
        const savedProducts = localStorage.getItem("products");
        if (savedProducts) {
            try {
                const parsed = JSON.parse(savedProducts);
                // Check if products have prices property and updated images
                const hasAllPrices = parsed.every((p)=>p.prices);
                const hasOldImages = parsed.some((p)=>p.images.some((img)=>img.includes('unsplash.com')));
                if (hasAllPrices && !hasOldImages) {
                    setProducts(parsed);
                } else {
                    // Reset to initial products if any product is missing prices or has old images
                    setProducts(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$products$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["products"]);
                    localStorage.setItem("products", JSON.stringify(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$products$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["products"]));
                }
            } catch (e) {
                // If parsing fails, use initial products
                setProducts(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$products$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["products"]);
                localStorage.setItem("products", JSON.stringify(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$products$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["products"]));
            }
        } else {
            setProducts(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$products$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["products"]);
            // Save initial products to localStorage
            localStorage.setItem("products", JSON.stringify(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$products$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["products"]));
        }
        setIsLoading(false);
    }, []);
    const saveProducts = (newProducts)=>{
        console.log("saveProducts called with:", newProducts);
        setProducts(newProducts);
        localStorage.setItem("products", JSON.stringify(newProducts));
        console.log("Products saved to localStorage!");
        console.log("Verifying save:", localStorage.getItem("products"));
    };
    const addProduct = (product)=>{
        console.log("addProduct called with:", product);
        console.log("Current products:", products);
        const newProducts = [
            ...products,
            product
        ];
        console.log("New products array:", newProducts);
        saveProducts(newProducts);
        console.log("Product added and saved!");
    };
    const updateProduct = (id, updatedProduct)=>{
        console.log("updateProduct called with:", id, updatedProduct);
        console.log("Current products:", products);
        const newProducts = products.map((p)=>p.id === id ? updatedProduct : p);
        console.log("New products array:", newProducts);
        saveProducts(newProducts);
        console.log("Product updated and saved!");
    };
    const deleteProduct = (id)=>{
        const newProducts = products.filter((p)=>p.id !== id);
        saveProducts(newProducts);
    };
    const getProductById = (id)=>{
        return products.find((p)=>p.id === id);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])(ProductsContext.Provider, {
        value: {
            products,
            isLoading,
            addProduct,
            updateProduct,
            deleteProduct,
            getProductById
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/lib/products-store.tsx",
        lineNumber: 91,
        columnNumber: 5
    }, this);
}
function useProducts() {
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(ProductsContext);
    if (context === undefined) {
        throw new Error("useProducts must be used within a ProductsProvider");
    }
    return context;
}
}}),
"[project]/src/lib/settings-store.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "SettingsProvider": (()=>SettingsProvider),
    "useSettings": (()=>useSettings)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const SettingsContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const defaultSettings = {
    description: "At Jewelry Doctor, we specialize in all types of jewelry repair, from resizing rings and fixing chains to replacing watch batteries and repairing settings. We also offer custom jewelry design, engraving, and plating services, helping you create or restore pieces exactly the way you want them. One of our most popular features is same-day jewelry repair, so you can get your treasured items back quickly and in perfect condition.",
    subtitle: "Create your perfect ring with our custom design options."
};
function SettingsProvider({ children }) {
    const [settings, setSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(defaultSettings);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const savedSettings = localStorage.getItem("settings");
        if (savedSettings) {
            setSettings(JSON.parse(savedSettings));
        }
    }, []);
    const updateSettings = (newSettings)=>{
        setSettings(newSettings);
        localStorage.setItem("settings", JSON.stringify(newSettings));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])(SettingsContext.Provider, {
        value: {
            settings,
            updateSettings
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/lib/settings-store.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
}
function useSettings() {
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(SettingsContext);
    if (context === undefined) {
        throw new Error("useSettings must be used within a SettingsProvider");
    }
    return context;
}
}}),
"[project]/src/app/ClientBody.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ClientBody)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$products$2d$store$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/products-store.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$settings$2d$store$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/settings-store.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function ClientBody({ children }) {
    // Remove any extension-added classes during hydration
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // This runs only on the client after hydration
        document.body.className = "antialiased";
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])("div", {
        className: "antialiased",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AuthProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$settings$2d$store$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SettingsProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$products$2d$store$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProductsProvider"], {
                    children: children
                }, void 0, false, {
                    fileName: "[project]/src/app/ClientBody.tsx",
                    lineNumber: 23,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/ClientBody.tsx",
                lineNumber: 22,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/ClientBody.tsx",
            lineNumber: 21,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/ClientBody.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__7647ec98._.js.map